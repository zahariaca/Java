#!/bin/bash

echo "*** GET /employees/lastname/S ***"
curl -i -X GET http://localhost:8080/employees/lastname/S
