#!/bin/bash

echo "*** GET /employees ***"
curl -i -X GET http://localhost:8080/employees
