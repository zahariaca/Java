#!/bin/bash

echo "*** GET /employees/title/S **"
curl -i -X GET http://localhost:8080/employees/title/S
